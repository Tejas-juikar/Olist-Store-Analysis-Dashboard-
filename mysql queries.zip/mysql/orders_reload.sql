create database tejas;
Set sql_mode = "";
load data infile 'C:\ProgramData\MySQL\MySQL Server 8.0\Data\tejas\orders_dataset.csv' into table orders_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;
