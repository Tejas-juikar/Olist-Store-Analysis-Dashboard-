create table orders_data (
customer_id varchar(100),
order_status varchar(100),
order_purchase_timestamp date,
order_approved_at date,
order_delivered_carrier_date date,
order_delivered_customer_date date,
order_estimated_delivery_date date
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/orders_data_set.csv' 
INTO TABLE orders_data 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;