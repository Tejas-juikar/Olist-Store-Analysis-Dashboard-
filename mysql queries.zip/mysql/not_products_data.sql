create table products(
product_id varchar(500),
product_category_name varchar(500),
product_name_lenght bigint,
product_description_lenght bigint,
product_photos_qty bigint,
product_weight_g bigint,
product_length_cm bigint,
product_height_cm bigint,
product_width_cm bigint
);

Set sql_mode = "";
LOAD DATA INFILE 'C:/ProgramData/MySQL/products_data.csv' 
INTO TABLE products
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from products;