create table order_reviews (
review_id varchar(100),
order_id varchar(100),
review_score int,
review_comment_title varchar(100),
review_comment_message varchar(500),
review_creation_date date,
review_answer_timestamp date
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_order_reviews_dataset.csv' 
INTO TABLE order_reviews
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from order_reviews;