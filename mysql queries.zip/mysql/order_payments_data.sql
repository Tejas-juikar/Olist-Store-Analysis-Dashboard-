create table order_payments (
order_id varchar(100),
payment_sequential int,
payment_type varchar(100),
payment_installments int,
payment_value double
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_order_payments_dataset.csv' 
INTO TABLE order_payments
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from order_payments;