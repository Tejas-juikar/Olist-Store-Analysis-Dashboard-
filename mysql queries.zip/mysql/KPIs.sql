# KPI 1 -- weekday vs weekend payment statistics
create table KPI1
SELECT 
  (SELECT round(sum(p.payment_value),0) FROM orders_data o inner join order_payments p using(order_id) WHERE o.day_type="weekend") AS weekend_count, 
  (SELECT round(sum(p.payment_value),0) FROM orders_data o inner join order_payments p using(order_id) WHERE o.day_type="weekday") AS weekday_count;


# KPI 2 -- no. of orders with review score 5 and payment type as credit card
create table KPI2
select count(distinct orrev.review_id)
from order_reviews orrev inner join order_payments orpay using(order_id)
where orrev.review_score = 5 and orpay.payment_type = 'credit_card';


# kpi3 Average number of days taken for order_delivered_customer_date for pet_shop
create table KPI3
select round(avg(o.number_of_days),0) as Number_of_days
from orders_data o left join order_items orit using (order_id)
left join products p using(product_id)
where p.product_category_name = "pet_shop" ;


# KPI 4 -- Average price and payment values from customers of sao paulo city
create table KPI4
select avg(oritm.price) as average_price ,
avg(orpay.payment_value) as average_payment from
customers c inner join orders_data ordata using(customer_id) inner join 
order_items oritm using(order_id) left join order_payments orpay using(order_id) 
left join seller slr using(seller_id) 
where c.customer_city = 'sao paulo';


# kpi5 Relationship between shipping days (order_delivered_customer_date - order_purchase_timestamp) Vs review scores.
create table KPI5
select rev.review_score , round(avg(o.number_of_days),2)
from orders_data o left join order_reviews rev using (order_id)
group by rev.review_score
order by rev.review_score asc;


# kpi6 year wise count of orders and payment values
select year(o.order_purchase_timestamp) as year , count( distinct o.order_id) as total_orders, round(sum(p.payment_value),2) as total_payment 
from orders_data o inner join order_payments p using (order_id) 
group by year
order by year desc;
