create table seller (
seller_id varchar(100),
seller_zip_code_prefix int,
seller_city varchar(100),
seller_state varchar(100)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_sellers_dataset.csv' 
INTO TABLE seller
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from seller;