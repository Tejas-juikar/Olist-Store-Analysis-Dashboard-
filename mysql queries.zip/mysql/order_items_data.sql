create table order_items (
order_id varchar(100),
order_item_id int,
product_id varchar(100),
seller_id varchar(100),
shipping_limit_date date,
price double,
freight_value double
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/order_items_dataset.csv' 
INTO TABLE order_items
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from order_items;

