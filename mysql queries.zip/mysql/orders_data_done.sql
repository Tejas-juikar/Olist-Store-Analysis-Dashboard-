create table orders_data (
order_id varchar(100),
customer_id varchar(100),
order_status varchar(100),
order_purchase_timestamp date,
order_approved_at date,
order_delivered_carrier_date date,
order_delivered_customer_date date,
order_estimated_delivery_date date
);

Set sql_mode = "";

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_orders_dataset.csv' 
INTO TABLE orders_data 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

# adding column for weekday numbers
alter table orders_data add column weekday_number int;
set sql_safe_updates = 0;
update orders_data
set weekday_number = dayofweek(order_purchase_timestamp);

# adding column for day type - weekday or weekend
alter table orders_data add column day_type varchar(10);
update orders_data
set day_type = case
	when weekday_number in (1,7) then "weekend"
    else "weekday"
    end ;

# adding column for shipping days
alter table orders_data add column number_of_days int;
set sql_safe_updates = 0;
update orders_data
set number_of_days = datediff(order_delivered_customer_date,order_purchase_timestamp) ;

select count(*) from orders_data;

