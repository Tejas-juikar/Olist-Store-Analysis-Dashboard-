create table geolocations (
geolocation_zip_code_prefix int,
geolocation_lat double,
geolocation_lng double,
geolocation_city varchar(100),
geolocation_state varchar(100)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_geolocation_dataset.csv' 
INTO TABLE geolocations
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from geolocations;