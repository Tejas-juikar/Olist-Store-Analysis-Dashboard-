create table customers (
customer_id varchar(100),
customer_unique_id varchar(100),
customer_zip_code_prefix int,
customer_city varchar(100),
customer_state varchar(100)
);

LOAD DATA INFILE 'C:/ProgramData/MySQL/olist_customers_dataset.csv' 
INTO TABLE customers
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select count(*) from customers;